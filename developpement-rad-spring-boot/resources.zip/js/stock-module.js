(function(){
	angular
		.module("Stock", []);
})();